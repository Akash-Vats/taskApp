import 'dart:developer';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebaseproject/Screens/home_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../main.dart';

class LoginProvider extends ChangeNotifier{
  String storedDisplayNames = 'N/A';
  String storedEmail = 'N/A';

  bool isLoading=false;

TextEditingController emailController=TextEditingController();
TextEditingController passController=TextEditingController();


  Future login(BuildContext context)async{
    notifyListeners();
    isLoading=true;
    FirebaseAuth auth=FirebaseAuth.instance;
try{
 UserCredential? credential= await auth.signInWithEmailAndPassword(
     email: emailController.text.trim().toString(),
     password: passController.text.trim().toString());
 User? user= credential.user;
 if(user!=null){
log("---------email------${user.email}");
   SharedPreferences prefs = await SharedPreferences.getInstance();
   prefs.setString('email', user.email ?? 'N/A');

   storedEmail = user.email ?? 'N/A';
   notifyListeners();


ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Login succesfully")));
Navigator.push(context, MaterialPageRoute(builder: (context)=>const HomeScreen()));
isLoading=false;
 }
 else{
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text("user not found") ));
isLoading=false;
 }

 emailController.clear();
 passController.clear();

notifyListeners();
}catch(e){
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
isLoading=false;
  emailController.clear();
  passController.clear();
notifyListeners();
}

  }

  Future<String> getEmail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    notifyListeners();
    return prefs.getString('email') ?? 'N/A';

  }

  Future<void> loadUserData() async {

    String email = await getEmail();

    storedEmail = email;
    notifyListeners();

  }

}