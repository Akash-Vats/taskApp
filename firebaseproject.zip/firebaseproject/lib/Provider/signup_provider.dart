import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebaseproject/Screens/login_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class SignUpProvider extends ChangeNotifier{
  bool isLoading=false;

  TextEditingController emailController=TextEditingController();
  TextEditingController passController=TextEditingController();


  Future login(BuildContext context)async{
    isLoading=true;
    notifyListeners();
    FirebaseAuth auth=FirebaseAuth.instance;
    try{
      UserCredential? credential= await auth.createUserWithEmailAndPassword(
          email: emailController.text.trim().toString(),
          password: passController.text.trim().toString());
      User? user= credential.user;
      if(user!=null){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("SignUp successfully")));
        Navigator.push(context, MaterialPageRoute(builder: (context)=>const LoginScreen()));
        isLoading=false;
      }
      else{
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text("user not found") ));
        isLoading=false;
      }

      emailController.clear();
      passController.clear();

      notifyListeners();
    }catch(e){
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      isLoading=false;
      emailController.clear();
      passController.clear();
      notifyListeners();
    }

  }
}