import 'dart:developer';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/timezone.dart';

import 'package:timezone/data/latest.dart' as tzdata;




class NotificationService {
  NotificationService();
  final FlutterLocalNotificationsPlugin notificationsPlugin = FlutterLocalNotificationsPlugin();


  Future<void> initNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid = AndroidInitializationSettings('@drawable/avatar');
    var initializationSettingsIOS = DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        defaultPresentSound: true,
        onDidReceiveLocalNotification: (int id, String? title, String? body, String? payload) async {});


    var initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid,
        iOS: initializationSettingsIOS);

    await notificationsPlugin.initialize(initializationSettings,
        onDidReceiveNotificationResponse: (NotificationResponse notificationResponse) async {
          if(notificationResponse!=null){
            log("<<-------Response-------->$notificationResponse");
          }
        });
  }



  notificationDetails() {
    return const NotificationDetails(
      android: AndroidNotificationDetails(
          'your_channel_id',
          'your_channel_name',
          importance: Importance.high,
          priority:  Priority.max,
          playSound: true),
      iOS: DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,),);
  }
  // showing notification
  Future<void> showNotification({int id = 0, String? title, String? body, String? payload}) async {
    return notificationsPlugin.show(id, title, body, notificationDetails());
  }



  Future<void> scheduleNotification({int id = 0, String? title, String? body, String? payLoad,  scheduledNotificationDateTime}) async {

    final scheduledDate = TZDateTime.from(scheduledNotificationDateTime, tz.local);

    log("<<--------scheduledDate----->$scheduledDate");
    return notificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      scheduledDate,
      await notificationDetails(),
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: 'launch_background',
      androidAllowWhileIdle: true,
    );
  }

  Future<void> cancelNotification(int notificationId) async {
    await notificationsPlugin.cancel(notificationId);
  }
}
