

import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebaseproject/Provider/login_provider.dart';
import 'package:firebaseproject/Screens/login_screen.dart';
import 'package:firebaseproject/main.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:shared_preferences/shared_preferences.dart';





class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {



  bool isLoading=false;


  @override
  void initState() {
Provider.of<LoginProvider>(context,listen: false).loadUserData();

    // TODO: implement initState
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    final provider=Provider.of<LoginProvider>(context);

    var size=MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.26, 0.2],
              colors: [
                Colors.blue,
                Colors.white,

              ],)
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 28,left: 10),
              child: Container(
                alignment: Alignment.topLeft,
                child: IconButton(
                  onPressed:(){
                    Navigator.pop(context);
                  },
                  icon: Icon(Icons.arrow_back,color: Colors.white,),
                ),
              ),
            ),
             const Stack(
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 62),
                  child: CircleAvatar(
                    radius: 70,
                    backgroundColor: Color(0xffF3b5241),
                    backgroundImage: AssetImage("assets/images/profile.png"),
                  ),
                ),
              ],
            ),

            SizedBox(height: 10,),
            Text(provider.storedEmail,style: TextStyle(fontSize: 24,fontWeight: FontWeight.w700,color: Colors.blueGrey),),
            SizedBox(height: 15,),
            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Text("Settings",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.blueGrey),),
                )
              ],),

            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20,top: 10),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(
                        color: Colors.grey,
                        width: 0,
                        style: BorderStyle.solid),
                    borderRadius: BorderRadius.circular(5),

                    boxShadow: const [
                      BoxShadow(
                        color: Colors.grey,
                        offset: Offset(
                          3,
                          3,
                        ),
                        blurRadius: 6,
                        spreadRadius: 1,
                      ), //BoxShadow
                      BoxShadow(
                        color: Colors.white,
                      ),
                    ]
                ),
                child: Column(
                  children:  [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 20),
                          child: Text("Privacy Policy",style: TextStyle(fontWeight: FontWeight.w300,fontFamily: 'Regular',color: Colors.grey,fontSize: 19),),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 15),
                          child: IconButton( onPressed: (){

                            /* ImagePick().uploadImage();*/


                          } ,icon: Icon(Icons.arrow_forward_ios),),
                        ),
                      ],
                    ),
                    const Divider(
                      height: 3,
                      color: Colors.grey,
                      thickness: 1,

                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 20),
                          child: Text("Rating",style: TextStyle(fontWeight: FontWeight.w300,fontFamily: 'Regular',color: Colors.grey,fontSize: 19),),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 15),
                          child: IconButton( onPressed: (){} ,icon: Icon(Icons.arrow_forward_ios),),
                        ),
                      ],
                    ),
                    Divider(
                      height: 3,
                      color: Colors.grey,
                      thickness: 1,

                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Text("Feedback",style: TextStyle(fontWeight: FontWeight.w300,fontFamily: 'Regular',color: Colors.grey,fontSize: 19),),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 15),
                          child: IconButton( onPressed: (){} ,icon: Icon(Icons.arrow_forward_ios_sharp),),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20,),
            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: Text("Logout",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.blueGrey),),
                )
              ],),

            InkWell(onTap: (){

              signOut();
              setState(() {
                isLoading=true;
              });
            },
              child: Padding(    padding: const EdgeInsets.only(left: 20,right: 20,top: 10),
                child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(
                          color: Colors.grey,
                          width: 0,
                          style: BorderStyle.solid),
                      borderRadius: BorderRadius.circular(5),

                      boxShadow: const [
                        BoxShadow(
                          color: Colors.grey,
                          offset: Offset(
                            3,
                            3,
                          ),
                          blurRadius: 6,
                          spreadRadius: 1,
                        ), //BoxShadow
                        BoxShadow(
                          color: Colors.white,
                        ),
                      ]
                  ),
                  child: isLoading ? Center(child: CircularProgressIndicator(color: Colors.black,)): Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: Text("Logout",style: TextStyle(fontWeight: FontWeight.w300,fontFamily: 'Regular',color:Colors.grey ,fontSize: 19),),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 15),
                        child: IconButton( onPressed: (){

                          signOut();

                        } ,icon: Icon(Icons.logout),),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


  Future<void> signOut()async{
    try{

      await  FirebaseAuth.instance.signOut();

     Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
    }
    catch(e){
      print("error$e");
    }

  }







}
