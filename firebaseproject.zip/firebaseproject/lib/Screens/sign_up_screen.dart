import 'package:firebaseproject/Provider/signup_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../Provider/login_provider.dart';
import 'login_screen.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  bool password=false;
  @override
  Widget build(BuildContext context) {
    var size=MediaQuery.of(context).size;
    final provider=Provider.of<SignUpProvider>(context);
    return Scaffold(body:
    Padding(
      padding: const EdgeInsets.all(15),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text("Register  Here",style: TextStyle(fontSize: 30,color: Colors.orange,fontWeight: FontWeight.bold),),
          const SizedBox(height: 10,),
          TextField(

            controller: provider.emailController,
            decoration: InputDecoration(
                hintText: "email",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
          const SizedBox(height: 20,),
          TextField(
            obscureText: !password,
            controller:provider.passController,
            decoration: InputDecoration(
                suffixIcon: IconButton(onPressed: (){
              setState(() {
                password=!password;
              });
            },
              icon:Icon(password ? Icons.visibility:Icons.visibility_off,color: Colors.black,),
            ),
                hintText: "password",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),),
          SizedBox(height: 10,),
          SizedBox(height: size.height/16,width: size.width,child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              elevation: 2,
                shadowColor: Colors.grey,
                backgroundColor:Colors.orange,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () {
              if(provider.emailController.text.trim().isEmpty){
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("enter email")));
              }
              else if(provider.passController.text.trim().isEmpty){
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("enter password")));
              }
              else{
                provider.login(context);
              }

            },
            child: provider.isLoading? Center(child: CircularProgressIndicator(color: Colors.black54,),):
            Text("Signup",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),),),
          SizedBox(height: 10,),
          RichText(
            text: TextSpan(
                text: "Already have an account?",
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w400,
                    color: Colors.black),
                children: [
                  TextSpan(
                      text: " Login",
                      style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w400,
                          color: Colors.blue),
                        recognizer: TapGestureRecognizer()
                        ..onTap = () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const LoginScreen()));
                        }),
                ]),
          )
        ],),
    ),);

  }
}
