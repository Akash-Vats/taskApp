import 'dart:developer';

import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebaseproject/Provider/login_provider.dart';
import 'package:firebaseproject/Screens/login_screen.dart';
import 'package:firebaseproject/Screens/profile_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';



import 'package:timezone/timezone.dart' as tz;

import '../Services/notification_services.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TextEditingController titController=TextEditingController();
  TextEditingController desController=TextEditingController();
  TextEditingController dateinput = TextEditingController();
  TextEditingController titleController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();


 
  CollectionReference userCollection = FirebaseFirestore.instance.collection('users');

  User? user = FirebaseAuth.instance.currentUser;

  bool isLoading=false;
  String storedDisplayName = '';


  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String imageUrl="";
  NotificationService notificationService=NotificationService();


  @override
  void initState() {
    _timeOfDay;

Provider.of<LoginProvider>(context,listen: false).loadUserData();

    super.initState();
    dateinput.text = "";

  }
  DateTime now = DateTime.now();

  DateTime _dateTime = DateTime.now();
  TimeOfDay _timeOfDay = TimeOfDay.now();
  DateTime scheduledTime = DateTime.now();
  String time='';



  DateTime? dt;
  DateTime? selectedDate;
  TimeOfDay? selectedTime;
  String? formattedTime;
  bool validate=false;

  @override
  Widget build(BuildContext context) {
 final provider=Provider.of<LoginProvider>(context);
    var size=MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop:showExitPopup ,
      child: Scaffold(
        floatingActionButton: FloatingActionButton(
          backgroundColor: Color(0xffF009FFB),
          onPressed: () {
            titleController.clear();
            descriptionController.clear();

            showModalBottomSheet(
              isScrollControlled: true,
              context: context,
              builder: (context) {
                return StatefulBuilder(
                  builder: (BuildContext context,
                      void Function(void Function()) setState) {
                    return Padding(
                      padding: EdgeInsets.only(
                          bottom: MediaQuery.of(context).viewInsets.bottom),
                      child: SizedBox(
                        height: size.height/2.9,
                        child: Form(
                          key: formKey,
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 20, right: 20, top: 10),
                                child: TextFormField(
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Title';
                                    }
                                    return null;
                                  },
                                  controller: titleController,

                                  style: const TextStyle(
                                      fontSize: 20, fontWeight: FontWeight.bold),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10)),
                                    hintText: "Title",
                                    hintStyle: const TextStyle(
                                        fontSize: 20,
                                        fontFamily: 'Bold',
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 20, right: 20),
                                child: TextFormField(
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter description';
                                    }
                                    return null;
                                  },
                                  controller: descriptionController,
                                  keyboardType: TextInputType.multiline,
                                  maxLines: 2,
                                  maxLength: 100,
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      hintText: "Description",
                                      hintStyle: TextStyle(fontFamily: "Regular")),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 10, right: 10),
                                child: Row(
                                  children: [
                                    IconButton(
                                        onPressed: () async {
                                          TimeOfDay? pickedTime = await showTimePicker(
                                              context: context,
                                              initialTime: TimeOfDay.now(),
                                              initialEntryMode: TimePickerEntryMode.dialOnly);
                                          if (pickedTime == null) {
                                            setState(() {});
                                            // log("<----pickedTime---->$pickedTime");
                                            return;

                                          }
                                          else if(pickedTime.hour > now.hour || (pickedTime.hour == now.hour && pickedTime.minute > now.minute)){

                                            setState(() {
                                              _timeOfDay = pickedTime; //pass time
                                              selectedTime = pickedTime;
                                              formattedTime = '${selectedTime!.hourOfPeriod}:${selectedTime!.minute.toString().padLeft(2, '0')} '
                                                  '${selectedTime!.period == DayPeriod.am ? 'AM' : 'PM'}';
                                              scheduledTime = DateTime(now.year, now.month, now.day, pickedTime.hour, pickedTime.minute,);
                                            });
                                          }
                                      else  {
                                            setState(() {
                                              _timeOfDay = pickedTime; //pass time
                                              selectedTime = pickedTime; //save time here
                                              // format time here
                                          formattedTime = '${selectedTime!.hourOfPeriod}:${selectedTime!.minute.toString().padLeft(2, '0')} ${selectedTime!.period == DayPeriod.am ? 'AM' : 'PM'}';
                                              // log("<<<------formattedTime---->>>$formattedTime");
                                              // log("<<<------pickedTime---->>>$pickedTime");

                                       // schedule time here
                                               scheduledTime = DateTime(now.year, now.month, now.day, pickedTime.hour, pickedTime.minute,);
                                            });
                                          }

                                        },
                                        icon: const Icon(Icons.timer, color: Colors.grey,
                                        )),
                                    _timeOfDay ==TimeOfDay(hour: 0, minute: 0) ? Text("${TimeOfDay.now().hour.toString()}:${TimeOfDay.now().minute.toString()}"):
                                    Text("${_timeOfDay.hour}:${_timeOfDay.minute}",

                                      style: TextStyle(fontFamily: 'Regular'),
                                    ),
                                    IconButton(
                                        onPressed: () async {
                                          DateTime? pickedDate = await showDatePicker(
                                              context: context,
                                              initialDate: _dateTime,
                                              firstDate: DateTime.now(),
                                              lastDate: DateTime(2030));

                                          if (pickedDate == null) {
                                            setState(() {});
                                            return;
                                          } else {

                                            setState(() {
                                              _dateTime = pickedDate;
                                              selectedDate = pickedDate;
                                              var td=DateTime.now();
                                              // log("<<<<<------td------->>>>$td");
                                              // log("---selected date-----$selectedDate");
                                            });
                                          }
                                        },
                                        icon: Icon(
                                          Icons.calendar_month,
                                          color: Colors.grey,
                                        )),
                                    _dateTime==DateTime(_dateTime.year,_dateTime.month, _dateTime.day, )?
                                    Text("${_dateTime.year}/${_dateTime.month}/${_dateTime.day}",
                                      style: TextStyle(fontFamily: 'Regular'),
                                    ):    Text("${DateTime.now().year}/${DateTime.now().month}/${DateTime.now().day}",
                                      style: TextStyle(fontFamily: 'Regular'),
                                    ),
                                    SizedBox(
                                      width: 40,
                                      height: 10,
                                    ),
                                    InkWell(
                                      onTap: () {
                                        String id=DateTime.now().microsecondsSinceEpoch.toString();

                                        if(titleController.text.trim().isEmpty){

                                          ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(
                                                duration: Duration(seconds: 0),
                                                behavior: SnackBarBehavior.floating,
                                                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 275),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.all(Radius.circular(10)
                                                  ),
                                                ),
                                                content: Text("Enter Title"),

                                              )
                                          );
                                        }
                                        else if(descriptionController.text.trim().isEmpty){

                                          ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(
                                                duration: Duration(seconds: 0),
                                                behavior: SnackBarBehavior.floating,
                                                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 275),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.all(Radius.circular(10)
                                                  ),
                                                ),
                                                content: Text("Enter Description"),

                                              )
                                          );
                                        }

                                        else if(formattedTime==null){
                                          ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(
                                                duration: Duration(seconds: 0),
                                                behavior: SnackBarBehavior.floating,
                                                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 275),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.all(Radius.circular(10)
                                                  ),
                                                ),
                                                content: Text("enter  Time"),

                                              )
                                          );
                                        }
                                        else if(selectedDate==null){

                                          ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(
                                                duration: Duration(seconds: 0),
                                                behavior: SnackBarBehavior.floating,
                                                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 275),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.all(Radius.circular(10)

                                                  ),
                                                ),
                                                content: Text("enter Date"),

                                              )
                                          );
                                        }
                                        else {

                                          Navigator.pop(context);

                                          saveUserData();

                                        }

                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                          top: 10,
                                        ),
                                        child: Container(
                                          height: 40,
                                          width: 80,
                                          decoration: BoxDecoration(
                                            color: Colors.blue,
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          child: isLoading? const Center(child: CircularProgressIndicator(color: Colors.black,)):const Center(
                                              child: Text(
                                                "Save",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontFamily: 'Regular'),
                                              )),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            );
          },
          child: Icon(Icons.add),
        ),
        body: Padding(
          padding: EdgeInsets.only(top: 50),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.only(left: 30, right: 30, top: 5),
                child: Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
Text(provider.storedEmail,style: TextStyle(fontSize: 25,fontWeight: FontWeight.w700,color: Colors.black),),
                        const Text(
                          "You've got",
                          style: TextStyle(
                              fontSize: 25,
                              fontFamily: 'Bold',
                              fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                    Spacer(),
                    InkWell(
                      onTap: (){
      Navigator.push(context, MaterialPageRoute(builder: (context)=>const ProfileScreen()));
                      },
                      child: Container(

                        decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xffF3b5241),

                   image: DecorationImage(image: AssetImage("assets/images/profile.png",),fit: BoxFit.fill),
                        ),
                        height: 45,
                        width: 45,
                      ),
                    ),
                  ],
                ),
              ),


              StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).collection('user_data').snapshots(),
 /* stream: FirebaseFirestore.instance.collection("users").snapshots(),*/

                  builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                          child: CircularProgressIndicator(
                            color: Colors.black,
                          ));
                    }
                    if (snapshot.data!.docs.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.only(top: 200),
                        child: Center(
                          child: Text('NO Task Added',style: TextStyle(fontSize: 20,color: Colors.grey,fontWeight: FontWeight.w400)),
                        ),
                      );
                    } else {
                      return Expanded(
                        child: Padding(
                            padding: const EdgeInsets.only(bottom: 9),
                            child: ListView.builder(
                                itemCount: snapshot.data!.docs.length,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, index) {

                                  Timestamp timestamp = snapshot.data?.docs[index]['date'];
                                  DateTime dateTime = timestamp.toDate();
                                  String formattedDate = DateFormat('yyyy-MM-dd').format(dateTime);

                                  // for today and tomorrow

                                  String todayDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
                                  var prevDay =  DateTime.now().subtract(Duration(days: 1));
                                  String yesterday = DateFormat('yyyy-MM-dd').format(prevDay);



                                  return  GestureDetector(

                                    onTap: () {



                                    },
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Column(
                                          children:  [
                                            Padding(
                                              padding: EdgeInsets.only(left: 30, top: 6),
                                              child: (formattedDate.trim()==todayDate.trim()) ?
                                              const Text("Today", style: TextStyle(
                                                  fontSize: 20, fontFamily: 'Regular',
                                                  fontWeight: FontWeight.w300),) :

                                              const Text("Upcoming", style: TextStyle(
                                                  fontSize: 20,
                                                  fontFamily: 'Regular',
                                                  fontWeight: FontWeight.w300),),
                                            )
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 4,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 20, right: 20, top: 5),
                                          child: Container(

                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: Colors.grey ,
                                                width: 2,
                                              ),
                                              borderRadius: BorderRadius.circular(10),
                                            ),

                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Padding(
                                                      padding: const EdgeInsets.only(
                                                          left: 21, top: 5,right: 21),
                                                      child: Text(
                                                        snapshot.data!.docs[index]['title'],
                                                        style: const TextStyle(
                                                            fontWeight: FontWeight.bold,
                                                            fontFamily: 'Regular',
                                                            fontSize: 21,
                                                            color: Colors.black45),
                                                      ),
                                                    ),
                                                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      children: [

                                                        Padding(
                                                          padding: const EdgeInsets.only(right: 20),
                                                          child: IconButton(onPressed:(){
                                                            deleteTask(snapshot.data!.docs[index].reference);

                                                            int notificationId = 0; // Replace with the ID you stored
                                                            NotificationService().cancelNotification(notificationId);
                                                          }
                                                            , icon: Icon(Icons.delete,size: 30,),color: Colors.red,),
                                                        ),

                                                      ],)
                                                  ],
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.only(
                                                      left: 21, right: 21),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Expanded(
                                                        child: Text(snapshot.data!.docs[index]['description'],
                                                          style: const TextStyle(
                                                              color: Colors.grey,
                                                              fontFamily: 'Regular'),


                                                        ),

                                                      ),

                                                      Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            borderRadius:
                                                            BorderRadius.circular(30),
                                                            color: Colors.greenAccent,
                                                          ),
                                                          child: const Icon(Icons.check,
                                                            color: Colors.green,
                                                          ),
                                                        ),
                                                      ),


                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 18,
                                                ),

                                                Padding(
                                                  padding: EdgeInsets.only(left: 15),
                                                  child: Row(
                                                    children: [
                                                      const Icon(
                                                        Icons.timer,
                                                        color: Colors.grey,
                                                      ),
                                                      const SizedBox(
                                                        width: 5,
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets.only(
                                                            top: 5, left: 5),
                                                        child: Text(snapshot.data?.docs[index]['time'],
                                                          style: const TextStyle(
                                                              color: Colors.grey,
                                                              fontFamily: 'Regular'),
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        width: 22,
                                                      ),
                                                      const Icon(
                                                        Icons.calendar_month,
                                                        color: Colors.grey,
                                                      ),
                                                      const SizedBox(
                                                        width: 5,
                                                      ),
                                                      Padding(
                                                        padding:
                                                        EdgeInsets.only(top: 5),
                                                        child: Text(formattedDate.toString(),
                                                          style: const TextStyle(
                                                              color: Colors.grey,
                                                              fontFamily: 'Regular'),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),

                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                })
                        )
                        ,);
                    }


                  }),
            ],
          ),
        ),
      ),
    );
  }













  Future<void> saveUserData() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        String uid = user.uid ?? '';
        String userEmail = user.email ?? '';


        CollectionReference userCollection = FirebaseFirestore.instance.collection('users');
        await userCollection.doc(uid).collection('user_data').add

          ({
          'title': titleController.text,
          'description': descriptionController.text,
          "id": uid,
          'date': selectedDate?.toLocal(),
          'time': formattedTime,
        });

        NotificationService().scheduleNotification(
            title: titleController.text.trim().toString(),
            body: descriptionController.text.trim().toString(),
            scheduledNotificationDateTime: scheduledTime);

        titleController.clear();
        descriptionController.clear();

        _timeOfDay=TimeOfDay(hour: 0, minute: 0);
        setState((){});
        _dateTime=DateTime.now();

        setState((){});

      }
    } catch (e) {

      print('Error saving data: $e');
    }
  }

  Future<void> deleteTask(DocumentReference documentReference) async {
    try {
      await documentReference.delete();
      print('Task deleted successfully');
    } catch (e) {
      print('Error deleting task: $e');
    }
  }

  Future<bool> showExitPopup() async {
    return await showDialog(

      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        title: Text('Exit App'),
        content: Text('Do you want to exit an App?'),
        actions:[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  textStyle: TextStyle(color: Colors.blue),

                ),
                onPressed: () => Navigator.of(context).pop(false),
                //return false when click on "NO"
                child:Text('No'),
              ),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    textStyle: TextStyle(color: Colors.blue)
                ),
                onPressed: () => Navigator.of(context).pop(true),
                //return true when click on "Yes"
                child:Text('Yes'),
              ),
            ],)


        ],
      ),
    )??false;
  }

 /* Future updateData(BuildContext context,String title,String description)async{
    return  showDialog(context: context, builder: (context){
      return AlertDialog(title: const Center(child: Text("Update Data")),
        content: SingleChildScrollView(
          child: Column(children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(
                hintText: "Enter title",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10),

                ),


              ),
            ),
            SizedBox(height: 10,),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(
                hintText: "Enter Description",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10),

                ),


              ),
            ),

          ],),
        ),
        actions: [
          TextButton(onPressed: (){
            Navigator.pop(context);
          }, child: const Text("cancel")),
          TextButton(onPressed: (){
            if(titleController.text.trim().toString().isEmpty){
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Enter Name")));
            }
            else{

              userCollection.doc(FirebaseAuth.instance.currentUser!.uid).update({
                "title": titleController.text,
                "description":descriptionController.text,
              });

              Navigator.pop(context);

            }


          }, child: const Text("ok")),

        ],
      );
    });
  }*/

  

}

