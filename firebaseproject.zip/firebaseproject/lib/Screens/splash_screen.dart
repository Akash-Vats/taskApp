import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebaseproject/Screens/home_screen.dart';
import 'package:firebaseproject/Screens/login_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  void whereToGo(){
    Timer(const Duration(seconds: 3), () {
      User? user=FirebaseAuth.instance.currentUser;
      if(user!=null){
       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>const HomeScreen()));
      }
      else{
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>const LoginScreen()));
      }

    });
  }

  @override
  void initState() {
    // TODO: implement initState

    whereToGo();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset("assets/images/splash.png"),
          const SizedBox(height: 10,),
          const Text("Task Management",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 30,color: Colors.orange),)
      ],),
    );
  }
}
